[BITS 32]

extern _kernel_main
call _kernel_main
jmp $

kernel_main:
    mov edi, 0B8000
    mov esi, msg_kernel

.print_loop:
    lodsb
    cmp al, 0
    je .done
    stosb
    mov al, 0x07
    stosb
    jmp .print_loop
.done:
    jmp $

msg_kernel db 'Xeno-Os: Runing in 32 bit protected mode!', 0

times 512-($-$$) db 0