[BITS 16]
[ORG 0x7C00]

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti
    mov si, msg_loading
    call print_string
    pushfd
    pop eax
    mov ecx, eax
    xor, eax, 1 << 21
    push eax
    popfd
    pushfd
    pop eax
    cmp eax, ecx
    je .no_cpuid
    mov eax, 0x80000000
    cpuid
    cmp eax, 0x80000001
    jb .no_long_mode

.no_long_mode:
.no_cpuid:
    mov eax, cr0
    or eax, 1
    mov cr0, eax

    jmp 0x08:.protected_mod_entry
[BITS 32]
.protected_mod_entry:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x90000

    jmp kernel_main

gdt_start:
    dd 0
    dd 0
.code:
    dw 0xFFFF
    dw 0
    db 0
    db 100110110b
    db 11001111b
    db 0

.data:
    dw 0xFFFF
    dw 0
    db 0
    db 10010010b
    db 11001111b
    db 0
gdt_end:

gdt_descriptor:
    dw gdt_end - dgt_start - 1
    dd gdt_start

times 510-($-$$) db 0
dw 0xAA55
